# Surendra Property + Surendra Digital Solution

A starter full-stack project containing two branded sections on one website, with an Express backend, admin login, property listings, image uploads, and enquiry storage.

## Run locally
1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Initial admin login (LOCAL TEST ONLY)
- Username: `admin`
- Password: `ChangeMe123!`

Before any public deployment, set strong environment variables:
- `ADMIN_USER`
- `ADMIN_PASSWORD`
- `SESSION_SECRET`
- `NODE_ENV=production`

Example (PowerShell):
```powershell
$env:ADMIN_USER="your-admin-name"
$env:ADMIN_PASSWORD="use-a-long-unique-password"
$env:SESSION_SECRET="use-a-long-random-secret"
npm start
```

## Important hosting note
This is the working project source, not a live deployed website. Free hosting plans can have sleep limits and may not provide persistent storage for uploaded photos or JSON data. For a reliable public dynamic website, connect persistent database/file storage (for example Supabase + object storage) before deployment. Do not publish the default admin password. The contact/WhatsApp number is set to +91 91298 69775.
