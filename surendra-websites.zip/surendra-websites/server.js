const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA = path.join(ROOT, 'data.json');
const UPLOADS = path.join(ROOT, 'public', 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, JSON.stringify({ properties: [], enquiries: [] }, null, 2));
const readData = () => JSON.parse(fs.readFileSync(DATA, 'utf8'));
const saveData = d => fs.writeFileSync(DATA, JSON.stringify(d, null, 2));
const upload = multer({ storage: multer.diskStorage({ destination: (_,__,cb)=>cb(null,UPLOADS), filename: (_,file,cb)=>cb(null,Date.now()+'-'+file.originalname.replace(/[^a-zA-Z0-9._-]/g,'_')) }), limits: { fileSize: 5*1024*1024 }, fileFilter: (_,f,cb)=>cb(null,/^image\/(jpeg|png|webp|gif)$/.test(f.mimetype)) });
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: process.env.SESSION_SECRET || 'change-this-before-deployment', resave:false, saveUninitialized:false, cookie:{ httpOnly:true, sameSite:'lax', secure: process.env.NODE_ENV==='production', maxAge: 8*60*60*1000 } }));
app.use(express.static(path.join(ROOT,'public')));
const adminUser = process.env.ADMIN_USER || 'admin';
const adminPass = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const isAdmin = (req,res,next)=>req.session.admin ? next() : res.status(401).json({error:'Please login first'});
app.get('/api/properties', (req,res)=>res.json(readData().properties));
app.post('/api/enquiries', (req,res)=>{
  const { name, phone, message, type } = req.body;
  if(!name || !phone) return res.status(400).json({error:'Name and phone are required'});
  const d=readData(); d.enquiries.unshift({id:Date.now(),name:String(name).slice(0,80),phone:String(phone).slice(0,25),message:String(message||'').slice(0,1000),type:String(type||'general').slice(0,40),createdAt:new Date().toISOString()}); saveData(d); res.json({ok:true});
});
app.post('/api/login', (req,res)=>{
  const {username,password}=req.body;
  if(username===adminUser && password===adminPass){ req.session.admin=true; return res.json({ok:true}); }
  res.status(401).json({error:'Incorrect username or password'});
});
app.post('/api/logout', isAdmin, (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/data', isAdmin, (req,res)=>res.json(readData()));
app.post('/api/admin/properties', isAdmin, upload.single('photo'), (req,res)=>{
  const {title,category,location,price,area,description,whatsapp}=req.body;
  if(!title || !location) return res.status(400).json({error:'Title and location are required'});
  const d=readData(); const item={id:Date.now(),title,category:category||'Plot',location,price:price||'Contact for price',area:area||'',description:description||'',whatsapp:whatsapp||'9129869775',photo:req.file?'/uploads/'+req.file.filename:'',createdAt:new Date().toISOString()};
  d.properties.unshift(item); saveData(d); res.json({ok:true,item});
});
app.delete('/api/admin/properties/:id', isAdmin, (req,res)=>{
  const d=readData(); const item=d.properties.find(p=>p.id===Number(req.params.id));
  if(item?.photo){const f=path.join(ROOT,'public',item.photo.replace(/^\//,'')); if(fs.existsSync(f)) fs.unlinkSync(f);}
  d.properties=d.properties.filter(p=>p.id!==Number(req.params.id)); saveData(d); res.json({ok:true});
});
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.listen(PORT,()=>console.log(`Surendra websites running at http://localhost:${PORT}`));
